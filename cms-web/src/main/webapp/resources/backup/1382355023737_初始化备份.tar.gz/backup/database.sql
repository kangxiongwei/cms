-- MySQL dump 10.13  Distrib 5.1.26-rc, for Win32 (ia32)
--
-- Host: localhost    Database: fz_cms
-- ------------------------------------------------------
-- Server version	5.1.26-rc-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_attachment`
--

DROP TABLE IF EXISTS `t_attachment`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_attach` int(11) DEFAULT NULL,
  `is_img` int(11) DEFAULT NULL,
  `is_index_pic` int(11) DEFAULT NULL,
  `new_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `old_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `size` bigint(20) NOT NULL,
  `suffix` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `tid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK48549DCEEFDD7FD5` (`tid`),
  CONSTRAINT `FK48549DCEEFDD7FD5` FOREIGN KEY (`tid`) REFERENCES `t_topic` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_attachment`
--

LOCK TABLES `t_attachment` WRITE;
/*!40000 ALTER TABLE `t_attachment` DISABLE KEYS */;
INSERT INTO `t_attachment` VALUES (1,0,1,0,'1381632936871.png','003',907508,'png','application/octet-stream',1),(3,0,1,0,'1382350880548.png','001',660288,'png','application/octet-stream',3),(4,0,1,0,'1382350882247.png','002',1269090,'png','application/octet-stream',3);
/*!40000 ALTER TABLE `t_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_channel`
--

DROP TABLE IF EXISTS `t_channel`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `custom_link` int(11) DEFAULT NULL,
  `custom_link_url` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `is_index` int(11) DEFAULT '0',
  `is_top_nav` int(11) DEFAULT '0',
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `orders` int(11) NOT NULL,
  `recommend` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL,
  `type` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `show_index` int(11) DEFAULT NULL,
  `nav_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE79D7038D7DDF6E5` (`pid`),
  CONSTRAINT `FKE79D7038D7DDF6E5` FOREIGN KEY (`pid`) REFERENCES `t_channel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_channel`
--

LOCK TABLES `t_channel` WRITE;
/*!40000 ALTER TABLE `t_channel` DISABLE KEYS */;
INSERT INTO `t_channel` VALUES (1,0,'',0,1,'学校简介',1,0,0,0,NULL,NULL,10),(2,0,'',0,1,'校园之窗',2,0,0,0,NULL,NULL,20),(3,0,'',0,1,'教育科研',3,0,0,0,NULL,NULL,30),(4,0,'',0,1,'德育园地',4,0,0,0,NULL,NULL,40),(5,0,'',1,0,'勤耕园',5,0,0,0,NULL,NULL,0),(6,0,'',0,0,'发展动态',1,0,0,1,1,NULL,0),(7,0,'',1,0,'学校概况',2,0,0,2,1,NULL,0),(8,0,'',0,1,'师生风采',3,0,0,3,1,NULL,50),(9,0,'',0,1,'校园文化',4,0,0,1,1,NULL,90),(10,0,'',1,0,'校园快讯',1,0,0,1,2,NULL,0),(11,0,'',1,0,'校务公开',2,0,0,1,2,NULL,0),(12,0,'',0,0,'工作指南',3,0,0,1,2,NULL,0),(13,0,'',0,1,'党团工作',4,0,0,1,2,NULL,80),(14,0,'',0,0,'后勤保障',5,0,0,1,2,NULL,0),(15,0,'',1,0,'教科信息',1,0,0,1,3,NULL,0),(16,0,'',0,0,'教科成果',2,0,0,1,3,NULL,0),(17,0,'',0,0,'校本教研',3,0,0,1,3,NULL,0),(18,0,'',0,1,'学科资源',4,0,0,1,3,NULL,70),(19,0,'',0,0,'群星闪烁',1,0,0,3,4,NULL,0),(20,0,'',1,0,'德育建设',2,0,0,1,4,NULL,0),(21,0,'',0,0,'班级工作',3,0,0,1,4,NULL,0),(22,0,'',0,1,'学生工作',4,0,0,1,4,NULL,60),(23,0,'',0,0,'德育智慧',5,0,0,1,4,NULL,0),(24,0,'',0,0,'家长学校',6,0,0,1,4,NULL,0),(25,0,'',0,0,'学生文章',1,0,0,1,5,NULL,0),(26,0,'',0,0,'美术作品',2,0,0,3,5,NULL,0),(27,0,'',0,0,'摄影作品',3,0,0,3,5,NULL,0);
/*!40000 ALTER TABLE `t_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_cms_link`
--

DROP TABLE IF EXISTS `t_cms_link`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_cms_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link_id` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `link_url` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `new_win` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_bin NOT NULL,
  `type` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `link_clz` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `pos` int(11) NOT NULL,
  `url_class` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `url_id` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_cms_link`
--

LOCK TABLES `t_cms_link` WRITE;
/*!40000 ALTER TABLE `t_cms_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_cms_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_group`
--

DROP TABLE IF EXISTS `t_group`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descr` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_group`
--

LOCK TABLES `t_group` WRITE;
/*!40000 ALTER TABLE `t_group` DISABLE KEYS */;
INSERT INTO `t_group` VALUES (1,'','校办'),(2,'','教务处'),(3,'','总务处'),(4,'','教研室'),(5,'','教科室'),(6,'','政教处'),(7,'','文学社');
/*!40000 ALTER TABLE `t_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_group_channel`
--

DROP TABLE IF EXISTS `t_group_channel`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_group_channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `c_id` int(11) DEFAULT NULL,
  `g_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKB7D322B8D80AB7D1` (`c_id`),
  KEY `FKB7D322B8EF562C89` (`g_id`),
  CONSTRAINT `FKB7D322B8D80AB7D1` FOREIGN KEY (`c_id`) REFERENCES `t_channel` (`id`),
  CONSTRAINT `FKB7D322B8EF562C89` FOREIGN KEY (`g_id`) REFERENCES `t_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_group_channel`
--

LOCK TABLES `t_group_channel` WRITE;
/*!40000 ALTER TABLE `t_group_channel` DISABLE KEYS */;
INSERT INTO `t_group_channel` VALUES (1,1,1),(2,6,1),(3,7,1),(4,8,1),(5,9,1),(6,2,1),(7,10,1),(8,11,1),(9,12,1),(10,3,2),(11,18,2),(12,2,2),(13,11,2),(14,2,3),(15,11,3),(16,14,3),(17,2,4),(18,12,4),(19,3,5),(20,15,5),(21,16,5),(22,17,5),(23,2,6),(24,13,6),(25,4,6),(26,19,6),(27,20,6),(28,21,6),(29,22,6),(30,23,6),(31,24,6),(32,5,7),(33,25,7),(34,26,7),(35,27,7);
/*!40000 ALTER TABLE `t_group_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_index_pic`
--

DROP TABLE IF EXISTS `t_index_pic`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_index_pic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_date` datetime DEFAULT NULL,
  `link_type` int(11) DEFAULT NULL,
  `link_url` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `pic` longblob,
  `status` int(11) NOT NULL,
  `sub_title` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `thumbnail_pic` longblob,
  `title` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `new_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `old_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `pos` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_index_pic`
--

LOCK TABLES `t_index_pic` WRITE;
/*!40000 ALTER TABLE `t_index_pic` DISABLE KEYS */;
INSERT INTO `t_index_pic` VALUES (1,'2013-10-13 10:54:03',0,'',NULL,1,'测试图片',NULL,'测试图片','1381632767234.png',NULL,1);
/*!40000 ALTER TABLE `t_index_pic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_keyword`
--

DROP TABLE IF EXISTS `t_keyword`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_keyword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `name_full_py` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `name_short_py` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `times` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_keyword`
--

LOCK TABLES `t_keyword` WRITE;
/*!40000 ALTER TABLE `t_keyword` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_keyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_role`
--

DROP TABLE IF EXISTS `t_role`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `role_type` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_role`
--

LOCK TABLES `t_role` WRITE;
/*!40000 ALTER TABLE `t_role` DISABLE KEYS */;
INSERT INTO `t_role` VALUES (1,'超级管理员','ROLE_ADMIN'),(2,'文章审核人员','ROLE_AUDIT'),(3,'文章发布人员','ROLE_PUBLISH');
/*!40000 ALTER TABLE `t_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_topic`
--

DROP TABLE IF EXISTS `t_topic`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_topic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `channel_pic_id` int(11) DEFAULT NULL,
  `content` text COLLATE utf8_bin,
  `create_date` datetime DEFAULT NULL,
  `keyword` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `publish_date` datetime DEFAULT NULL,
  `recommend` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `summary` text COLLATE utf8_bin,
  `title` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `cname` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKA10609A4D7DDC618` (`cid`),
  KEY `FKA10609A452119F24` (`uid`),
  CONSTRAINT `FKA10609A452119F24` FOREIGN KEY (`uid`) REFERENCES `t_user` (`id`),
  CONSTRAINT `FKA10609A4D7DDC618` FOREIGN KEY (`cid`) REFERENCES `t_channel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_topic`
--

LOCK TABLES `t_topic` WRITE;
/*!40000 ALTER TABLE `t_topic` DISABLE KEYS */;
INSERT INTO `t_topic` VALUES (1,'超级管理员',0,'学校概况测试文章<img src=\"/cms/resources/upload/1381632936871.png\" id=\"attach_1\" alt=\"\" />','2013-10-13 10:55:48','','2013-10-13 10:55:48',0,1,'学校概况','测试文章',7,3,'学校概况'),(2,'超级管理员',0,'撒旦发撒旦发生大法十大','2013-10-18 18:07:59','','2013-10-18 18:07:59',0,1,'','撒他是否撒旦发撒旦发撒旦发生的发',10,3,'校园快讯'),(3,'超级管理员',0,'萨发撒旦发撒旦发生大法','2013-10-21 18:21:29','','2013-10-21 18:21:29',0,1,'','测试图片',10,3,'校园快讯');
/*!40000 ALTER TABLE `t_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_date` datetime DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nickname` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `phone` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `status` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_user`
--

LOCK TABLES `t_user` WRITE;
/*!40000 ALTER TABLE `t_user` DISABLE KEYS */;
INSERT INTO `t_user` VALUES (3,'2013-06-03 13:39:13','','超级管理员','192023a7bbd73250516f069df18b500','123',1,'admin');
/*!40000 ALTER TABLE `t_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user_group`
--

DROP TABLE IF EXISTS `t_user_group`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_user_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `g_id` int(11) DEFAULT NULL,
  `u_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK300645B6EF562C89` (`g_id`),
  KEY `FK300645B652467BF9` (`u_id`),
  CONSTRAINT `FK300645B652467BF9` FOREIGN KEY (`u_id`) REFERENCES `t_user` (`id`),
  CONSTRAINT `FK300645B6EF562C89` FOREIGN KEY (`g_id`) REFERENCES `t_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_user_group`
--

LOCK TABLES `t_user_group` WRITE;
/*!40000 ALTER TABLE `t_user_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user_role`
--

DROP TABLE IF EXISTS `t_user_role`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `r_id` int(11) DEFAULT NULL,
  `u_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK331DEE5F5243B387` (`r_id`),
  KEY `FK331DEE5F52467BF9` (`u_id`),
  CONSTRAINT `FK331DEE5F5243B387` FOREIGN KEY (`r_id`) REFERENCES `t_role` (`id`),
  CONSTRAINT `FK331DEE5F52467BF9` FOREIGN KEY (`u_id`) REFERENCES `t_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_user_role`
--

LOCK TABLES `t_user_role` WRITE;
/*!40000 ALTER TABLE `t_user_role` DISABLE KEYS */;
INSERT INTO `t_user_role` VALUES (1,1,3);
/*!40000 ALTER TABLE `t_user_role` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-10-21 11:30:22
